from tkinter import *
from tkinter import messagebox
import PIL
from PIL import ImageTk, Image
import pymysql
import os

root = Tk()
root.title("Attendance Using Face Recognition")
root.config(bg="white")
# root.geometry("550x340+480+230")
root.state("zoomed")
root.resizable(True, True)

lgnimgae = PIL.Image.open("images/Login/lgnframe.png")
lgnimgae = lgnimgae.resize((1530, 805))
lgnimgae = ImageTk.PhotoImage(lgnimgae)
lgn_label = Label(root,image=lgnimgae)
lgn_label.place(x=0, y=0)
'''
main_img = Image.open("images/Login/lgnframe.png")
main_img = main_img.resize((1530, 805))
main_img = ImageTk.PhotoImage(main_img)
img_label = Label(image=main_img)
img_label.place(x=0, y=0)
'''

usernameentry = Entry(root, relief=FLAT,bg = "white",fg ="#6b6a69",font=("yu gothic ui semibold", 14,'bold'))
usernameentry.place(x=968,y=372,width=250)

passentry = Entry(root, relief=FLAT,bg = "white",fg ="#6b6a69",font=("yu gothic ui semibold", 14))
passentry.place(x=968,y=485,width=250)
passentry.config(show="*")


def backtofront ():

    root.withdraw()
    os.system("python firstfront.py")


def lgnbtn():
    if usernameentry.get()=="" or passentry.get()=="":
        messagebox.showerror('Error',"All fields are required")
    else:
        try:
            con=pymysql.connect(host="localhost",user="root",password="",database="project")
            cur=con.cursor()
            cur.execute("select * from login where username=%s and password=%s",(usernameentry.get(),passentry.get()))
            row=cur.fetchall()



            if not row:
                messagebox.showerror("Error",'Credentials are wrong, Please recheck')
            else:
                root.withdraw()
                os.system("python dshboard.py")
            con.commit()
            con.close()

        except Exception as e:
            messagebox.showerror("Error",f"Error due to:{str(e)}")
            a=input()


back = ImageTk.PhotoImage \
    (file='images\Login\lgnback.png')
back_button = Button(root, image=back, relief=FLAT, borderwidth=0, background="white",
                     activebackground="white", cursor="hand2")
#back_button.bind("<Return>", backtofront)
back_button.place(x=1000, y=580)
back_button.config(command=backtofront)


loginbtn = ImageTk.PhotoImage \
            (file='images\Login\lgnbtn.png')
login_button = Button(root, image=loginbtn, relief=FLAT, borderwidth=0, background="white",
                                    activebackground="white", cursor="hand2")
login_button.place(x=1200, y=580)
login_button.config(command=lgnbtn)





root.mainloop()