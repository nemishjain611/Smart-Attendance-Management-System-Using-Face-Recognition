from sqlite3 import DatabaseError
import cv2
#import numpy as np
#import face_recognition
import os
from datetime import datetime
from datetime import date
import datetime
from tkinter import messagebox
import pymysql
import csv
import pickle
import pyttsx3

ImageTraningModel = pickle.load(open('ImageTraningModel.pkl', 'rb'))

today = date.today()
print("Taking attendance for", today)

con = pymysql.connect(host="localhost", user="root", password="", database="project")
cur = con.cursor()
print("Database is connected")
path = 'TrainingImage'
images = []
classNames = []
myList = os.listdir(path)
# print(myList)

#cur = con.cursor()
cur.execute('select * from employee')
rows = cur.fetchall()
print(rows)

print("adding values to sql file")


def search(employee_id):
    count = 0
    term = str(employee_id)
    reader = csv.reader(
        open(f'AttendanceSheet/{today.strftime("%B-%d-%Y")}.csv', 'r'))
    for row in reader:
        print(row)

        if row:
            if row[0] == term:
                count = count + 1
    return count
    # return True
    # return False # return None if no match'''


#AttendanceSheet\{today.strftime("%B-%d-%Y")}.csv


def markAttendance(name, id):
    print(name)
    with open(f'AttendanceSheet\{today.strftime("%B-%d-%Y")}.csv', 'a') as f:
        print("checking whether in or out")
        print("name", name)


        employee_id = id
        employee_name=name
        #print(name)
        inorout = search(employee_id)
        print("first record?", inorout)
        print("writing into attendance.csv")

        # using datetime module

        # ct stores current time
        timestamp = datetime.datetime.now()
        print("current time:-", timestamp)

        # ts store timestamp of current time
        ts = timestamp.timestamp()
        print("timestamp:-", ts)
        try:
            if (inorout  == 0):  # remove %2 from both to get one single record of per employeeand uncomment else
                print("adding values to csv files")
                f.writelines(f'\n{employee_id},{name},{timestamp}, IN TIMING')
                sql = f"INSERT INTO ATTENDANCE (EMPLOYEE_ID, EMPLOYEE_NAME, INOROUT) VALUES({employee_id}, '{name}','IN TIMING'); "
                #print(sql)
                cur.execute(sql)
                print("adding values to sql file")
            elif (inorout == 1):  # %2
                print("adding values to csv files")
                f.writelines(f'\n{employee_id},{name},{timestamp}, OUT TIMING')
                sql = f"INSERT INTO ATTENDANCE (EMPLOYEE_ID, EMPLOYEE_NAME, INOROUT) VALUES({employee_id},'{name}', 'OUT TIMING'); "
                cur.execute(sql)

            else:
                messagebox.showerror(title="success", message="Attendance has been marked for the day")
            con.commit()
        except DatabaseError as e :
            #print(e)
            print("check database file if any error persissts")
        return 0


#### FOR CAPTURING SCREEN RATHER THAN WEBCAM
# def captureScreen(bbox=(300,300,690+300,530+300)):
#     capScr = np.array(ImageGrab.grab(bbox))
#     capScr = cv2.cvtColor(capScr, cv2.COLOR_RGB2BGR)
#     return capScr

encodeListKnown = ImageTraningModel
print('Encoding Complete')

recognizer = cv2.face.LBPHFaceRecognizer_create()  # cv2.createLBPHFaceRecognizer() #imp
recognizer.read("TrainingImageLabel\Trainner.yml")
harcascadePath = "haarcascade_frontalface_default.xml"
faceCascade = cv2.CascadeClassifier(harcascadePath);  # imp
cam = cv2.VideoCapture(0)
font = cv2.FONT_HERSHEY_SIMPLEX
print("Capturing video")
attendance = True
empname = ""
empID = 0
gotoAttdence = 0
Id = -1
while True:
    ret, im = cam.read()
    gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
    faces = faceCascade.detectMultiScale(gray, 1.2, 5)
    for (x, y, w, h) in faces:
        cv2.rectangle(im, (x, y), (x + w, y + h), (225, 0, 0), 2)
        Id, conf = recognizer.predict(gray[y:y + h, x:x + w])  # important line
        if (conf < 40):
            print("passs")
            for row in rows:
                print('w', Id, row[2])
                print(type(Id), type(row[2]))
                if (row[2] == str(Id)):
                    tt = str(Id) + "-" + row[0]
                    empname = row[0]
                    attendance = False
                    break
                else:
                    tt = str(Id) + "- no nameFound in DB"
            # attendance.loc[len(attendance)] = [Id,aa,date,timeStamp]
        else:
            Id = -1
            tt = str("unknown")
        cv2.putText(im, str(tt), (x, y + h), font, 1, (255, 255, 255), 2)
        # attendance=attendance.drop_duplicates(subset=['Id'],keep='first')
    cv2.imshow('img', im)
    if (Id != -1):
        print("Id*********************************")
        print(Id)
        print("Id*********************************")
        print("conf*********************************")
        print(conf)
        print("conf*********************************")

    if (cv2.waitKey(1)== ord('q')):  #clicking q to close camera
        cam.release()
        cv2.destroyAllWindows()
        break
    # cv2.imshow('Webcam', img)
    # cv2.waitKey(1)

if attendance == False:
    engine = pyttsx3.init()
    engine.say("Your Attendance Has Been Marked!")
    engine.runAndWait()
    markAttendance(empname, Id)
    employee_name = empname
    message = "Attendance marked for " + employee_name + " ! Now you can turn off camera"
    messagebox.showinfo(title="Done!", message=message)


else:
    engine = pyttsx3.init()
    engine.say("You are Unknown Person! ")
    engine.runAndWait()

    message = "Unknown person!!! Now you can turn off camera"
    messagebox.showinfo(title="Done!", message=message)


    #exit()


