from tkinter import *
import PIL
from PIL import ImageTk, Image
import csv
from tkinter import messagebox, ttk,filedialog
from tkinter.ttk import Combobox, Treeview
from tkcalendar import *
import cv2
import pymysql
import os

from tkcalendar import *
import PIL
root = Tk()
root.title("Attendance Using Face Recognition")
root.config(bg="white")
root.state("zoomed")
root.resizable(True, True)

def monthlyattbtncmd():
    root.withdraw()
    os.system("python Report.py")

dailattenbg = PIL.Image.open("images/Daily Attendance\Daily attendance.png")
dailattenbg = dailattenbg.resize((1528, 796))
dailattenbg = ImageTk.PhotoImage(dailattenbg)
dailattenbg_label = Label(image=dailattenbg)
dailattenbg_label.place(x=0, y=0)

idvalue=StringVar()
datevalue=StringVar()

def bckbtn():
    root.withdraw()
    os.system("python dshboard.py")

def showcmd():
    def showrec(rows):
        if len(rows) != 0:
            table.delete(*table.get_children())
            for row in rows:
                table.insert('', END, values=row)
            con.commit()
        else:
            messagebox.showerror(message="No Records Found in Database, Please Enter Correct Details")
            idvalue.set("")
            datevalue.set("")

    con = pymysql.connect(host="localhost", user="root", password="", database="project")
    cur = con.cursor()

    if idvalue.get()!="" and datevalue.get()=="":
        cur.execute("SELECT * FROM attendance WHERE EMPLOYEE_ID=  %s", idvalue.get())
        rows = cur.fetchall()
        showrec(rows)
    elif datevalue.get()!="" and idvalue.get()=="":
        cur.execute("SELECT * FROM attendance WHERE Date(PUNCH) =%s", datevalue.get())
        rows = cur.fetchall()
        showrec(rows)
    elif idvalue.get() != "" and datevalue.get() != "":
        cur.execute("SELECT * FROM attendance WHERE EMPLOYEE_ID=  %s and Date(PUNCH) =%s ",(idvalue.get(), datevalue.get()))
        rows = cur.fetchall()
        showrec(rows)
    else:
        messagebox.showerror(message="Please Fill the Details!")


back = ImageTk.PhotoImage \
    (file='images/Attendance Report/previus.png')
back_button = Button(root, image=back, relief=FLAT, borderwidth=0, background="white",
                     activebackground="white", cursor="hand2")
back_button.place(x=20, y=15)
back_button.config(command=bckbtn)


monthlyatt = ImageTk.PhotoImage \
    (file='images/Daily Attendance/monthly att.png')
monthlyattbtn = Button(root, image=monthlyatt, relief=FLAT, borderwidth=0, background="white",
                      activebackground="white", cursor="hand2")
monthlyattbtn.place(x=150, y=12)
monthlyattbtn.config(command=monthlyattbtncmd)

#dateentry=StringVar()
date = DateEntry(root, font=('yu gothic ui semibold', 12), relief=FLAT, textvariable=datevalue, foreground="Black",
                     width=20, date_pattern='yyyy/mm/dd', borderwidth=0)
date._set_text("")
date.place(x=365, y=407)


btnshow = ImageTk.PhotoImage \
    (file='images/Attendance Report/Show.png')
show_button = Button(root, image=btnshow, relief=FLAT, borderwidth=0, background="white",
                      activebackground="white", cursor="hand2")
show_button.place(x=300, y=500)
show_button.config(command=showcmd)


#idvalue=StringVar()
identry = Entry(root, relief=FLAT, bg="white", fg="Black", font=("yu gothic ui semibold", 12, 'bold'),
                  textvariable=idvalue)
identry.place(x=373, y=334, width=200)
#nameentry.insert(0, 'Enter Full Name')


tableFrame = Frame(root, bg='white', relief=GROOVE, borderwidth=1)
tableFrame.place(x=730, y=200, width=700, height=500)

style = ttk.Style()
style.configure('Treeview.Heading', font=('arial', 10))
scroll_x = Scrollbar(tableFrame, orient=HORIZONTAL)
scroll_y = Scrollbar(tableFrame, orient=VERTICAL)
table = ttk.Treeview(tableFrame,
                     columns=('ID','Name', 'Punch', 'InOrOut')
                     , yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
scroll_x.pack(side=BOTTOM, fill=X)
scroll_y.pack(side=RIGHT, fill=Y)
scroll_x.config(command=table.xview)
scroll_y.config(command=table.yview)
table.heading('ID', text='ID')
table.column('ID', width=80)
table.heading('Name', text='Name')
table.column('Name', width=80)
table.heading('Punch', text='Punch')
table.column('Punch', width=80)
table.heading('InOrOut', text='InOrOut')
#table.column('Employee Id', width=100)
table['show'] = 'headings'
table.pack(fill=BOTH, expand=1)

table.bind("<ButtonRelease-1>")








root.mainloop()