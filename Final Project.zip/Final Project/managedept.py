from tkinter import *
import PIL
from PIL import ImageTk, Image
import csv
from tkinter import messagebox, ttk
from tkinter.ttk import Combobox, Treeview
from tkcalendar import *
import cv2
import pymysql

root = Tk()
root.title("Attendance Using Face Recognition")
root.config(bg="white")
# root.geometry("550x340+480+230")
root.state("zoomed")
root.resizable(True, True)

def fetch_deptname():
    con = pymysql.connect(host="localhost", user="root", password="", database="project")
    cur = con.cursor()
    cur.execute('select * from department')
    rows = cur.fetchall()
    if len(rows) != 0:
        table1.delete(*table1.get_children())
        for row in rows:
            table1.insert('', END, values=row)
        con.commit()
    con.close()

def deptclear():
    deptvar.set("")

def clear():
    deptvar.set("")

def deptaddcmd():
    con = pymysql.connect(host="localhost", user="root", password="", database="project")
    cur = con.cursor()
    if deptvar.get():
        cur.execute('insert into department values(%s)', (deptvar.get()))
        con.commit()
        messagebox.showinfo("Success", 'Successfully Added')
        fetch_deptname()
        deptclear()
        con.close()
        clear()
       # root.destroy()
       # import main
    else:
        messagebox.showerror(title="Error", message="Enter department name")

def deptdelete():
        con = pymysql.connect(host="localhost", user="root", password="", database="project")
        cur = con.cursor()
        cur.execute('delete from department where DEPARTMENT_NAME=%s', deptvar.get())
        con.commit()
        messagebox.showinfo("Success",'Successfully Deleted')
        fetch_deptname()
        deptclear()
        con.close()
    #    root.destroy()
      #  import main

def deptshowallbtn():
    con = pymysql.connect(host="localhost", user="root", password="", database="project")
    cur = con.cursor()
    cur.execute('select * from department')
    rows = cur.fetchall()
    if len(rows) != 0:
        table1.delete(*table1.get_children())
        for row in rows:
            table1.insert('', END, values=row)
        con.commit()
    con.close()

def get_deptname(ev):
    #department_names = "SELECT * FROM DEPARTMENT";
    cursor_row = table1.focus()
    contents = table1.item(cursor_row)
    row = contents['values']
    deptvar.set(row[0])

def backbtncmd():
    root.destroy()
    import dshboard

deptvar = StringVar()


def clickname(*args):
    deptadd.delete(0, 'end')


managedeptbg = PIL.Image.open("images/Dept Management/managedept.png")
managedeptbg = managedeptbg.resize((1528, 796))
managedeptbg = ImageTk.PhotoImage(managedeptbg)
mainbg_label = Label(image=managedeptbg)
mainbg_label.place(x=0, y=0)


deptadd = Entry(root, relief=FLAT, bg="white", fg="Black", font=("yu gothic ui semibold", 12, 'bold'),
                  textvariable=deptvar)
deptadd.place(x=480, y=349, width=240)
deptadd.insert(0, 'Enter Department Name')
deptadd.bind("<Button-1>", clickname)


deptaddbtn = ImageTk.PhotoImage \
    (file='images/Dept Management/detailadd.png')
deptadd_button = Button(root, image=deptaddbtn, relief=FLAT, borderwidth=0, background="white",
                    activebackground="white", cursor="hand2", command=deptaddcmd)
deptadd_button.place(x=300, y=500)


deptdeletebtn = ImageTk.PhotoImage \
    (file='images/Dept Management/detaildelete.png')
deptdelete_button = Button(root, image=deptdeletebtn, relief=FLAT, borderwidth=0, background="white",
                       activebackground="white", cursor="hand2", command=deptdelete)
deptdelete_button.place(x=450, y=500)


deptshowall = ImageTk.PhotoImage \
    (file='images/Dept Management/showallbtn.png')
deptshowall_button = Button(root, image=deptshowall, relief=FLAT, borderwidth=0, background="white",
                        activebackground="white", cursor="hand2", command=deptshowallbtn)
deptshowall_button.place(x=600, y=500)

tableFramedept = Frame(root, bg='white', relief=GROOVE, borderwidth=1)
tableFramedept.place(x=900, y=280, width=500, height=300)

style = ttk.Style()
style.configure('Treeview.Heading', font=('arial', 10, 'bold'))
scroll_x = Scrollbar(tableFramedept, orient=HORIZONTAL)
scroll_y = Scrollbar(tableFramedept, orient=VERTICAL)
table1 = Treeview(tableFramedept, column=('DepartmentName'),
                  yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
scroll_x.pack(side=BOTTOM, fill=X)
scroll_y.pack(side=RIGHT, fill=Y)
scroll_x.config(command=table1.xview)
scroll_y.config(command=table1.yview)
table1.heading('DepartmentName', text='Department Name')

table1['show'] = 'headings'
table1.pack(fill=BOTH, expand=1)
table1.bind("<ButtonRelease-1>", get_deptname)

back = ImageTk.PhotoImage \
    (file='images/Dept Management/previus.png')
back_button = Button(root, image=back, relief=FLAT, borderwidth=0, background="white",
                     activebackground="white", cursor="hand2", command=backbtncmd)
back_button.place(x=20, y=15)
root.mainloop()