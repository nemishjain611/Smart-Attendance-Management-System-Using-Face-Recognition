import pymysql

con=pymysql.connect(host="localhost",user="root",password="",database="project")
cur=con.cursor()
'''
CREATEEMPLOYEETABLE = """CREATE TABLE IF NOT EXISTS EMPLOYEE
                    (EMPLOYEE_NAME VARCHAR(255), 
                    EMPLOYEE_GENDER VARCHAR(255), 
                    EMPLOYEE_ID INT NOT NULL UNIQUE, 
                    DEPARTMENT_NAME VARCHAR(255), 
                    CONTACTVAL VARCHAR(255), 
                    DATE_OF_BIRTH DATE, 
                    DATE_OF_JOINING DATE)"""
cur.execute(CREATEEMPLOYEETABLE)

sql=('CREATE TABLE IF NOT EXISTS DEPARTMENT (DEPARTMENT_NAME VARCHAR(255))')
cur.execute(sql)
'''
ATTENDANCE_TABLE = """
CREATE TABLE IF NOT EXISTS ATTENDANCE(EMPLOYEE_ID INT, EMPLOYEE_NAME VARCHAR(255), PUNCH TIMESTAMP, INOROUT VARCHAR(255))
"""

cur.execute(ATTENDANCE_TABLE)
'''
cur.execute("CREATE TABLE IF NOT EXISTS LOGIN(USERNAME VARCHAR(255), PASSWORD VARCHAR(255))")

sql = 'insert into LOGIN values("admin", "1234")'

cur.execute(sql)
'''
con.commit()


