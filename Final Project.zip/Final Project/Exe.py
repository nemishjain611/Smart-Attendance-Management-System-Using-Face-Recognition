import cx_Freeze
import sys
import os
base = None
if sys.platform == 'win32':
    base = "Win32GUI"

os.environ['TCL_LIBRARY'] = r"C:\Users\Nemish Jain\AppData\Local\Programs\Python\Python39\tcl\tcl8.6"
os.environ['TK_LIBRARY'] = r"C:\Users\Nemish Jain\AppData\Local\Programs\Python\Python39\tcl\tk8.6"

executables = [cx_Freeze.Executable("firstfront.py", base=base,icon="profile.ico")]

cx_Freeze.setup(
    name = "Taralac",
    options = {"build_exe": {"packages":["tkinter","os","sys","cv2","pymysql","csv","PIL","sqlite3","pickle","datetime","pandas","numpy","shutil"], "include_files":['tcl86t.dll','tk86t.dll','profile.ico','AttendanceSheet','images','Employee','Monthly Report','MonthlyAttendanceReports','TrainingImage','TrainingImageLabel','Dailyattendance.py','DatabaseGeneration.py','dshboard.py','Employee','firstfront.py','generatereports.py','haarcascade_frontalface_default.xml','ImageTraningModel','ImageTraningModel.pkl','lgn.py','mainfl.py','managedept.py','markattendanceMain.py','Report.py','trainhar.py']}},
    version = "1.00",
    description = "FRAS is Employee Payroll Management System  ",
    executables = executables
    )
