import pymysql
import csv
from datetime import date
import os.path
from os import path
from datetime import datetime
import datetime
months_list = [
    "January", 
    "February", 
    "March", 
    "April", 
    "May", 
    "June", 
    "July", 
    "August", 
    "September", 
    "October", 
    "November", 
    "December"
]

import os
 
con=pymysql.connect(host="localhost",user="root",password="",database="project")
cur=con.cursor()
cur.execute("SELECT EMPLOYEE_ID FROM EMPLOYEE")
cur.execute("DROP TABLE MONTHLYREPORTS"); 
monthlyreportstable = """CREATE TABLE IF NOT EXISTS MONTHLYREPORTS(
    MONTH_NAME VARCHAR(10),
    YEAR VARCHAR(4), 
    EMPLOYEE_ID INT, 
    EMPLOYEE_NAME VARCHAR(255), 
    DAYS INT 
)   """
cur.execute(monthlyreportstable)
today = date.today()

query = "SELECT * FROM EMPLOYEE"

cur.execute(query)

EMPLOYEE_RECORDS = cur.fetchall()
for month_name in months_list:
    import os
    year = today.strftime("%Y")
    if not path.isdir(f'MonthlyAttendanceReports/{year}'):
        os.mkdir(f"MonthlyAttendanceReports/{year}")
    file = f"MonthlyAttendanceReports/{year}/{month_name}.csv"
    if(os.path.exists(file) and os.path.isfile(file)):
        os.remove(file)
        print("file deleted")
    month_first_date = f"{year}-{str(months_list.index(month_name) + 1)}-01 00:00:00"
    month_last_date = f"{year}-{str(months_list.index(month_name) + 1)}-31 23:59:59"
    for e in EMPLOYEE_RECORDS:
        employee_id = e[0]
        employee_name = e[2]
        query = f"""
        SELECT COUNT(PUNCH) FROM ATTENDANCE WHERE EMPLOYEE_ID = "{employee_name}" 
        AND INOROUT = 'IN TIMING' AND PUNCH >= '{month_first_date}' AND PUNCH <= '{month_last_date}'
        """
        cur.execute(query)

        # exit()
        # for r in records:
        #     intiming = r
        intiming = cur.fetchone()
        intimin = intiming[0]


        with open(f'MonthlyAttendanceReports\{year}\{month_name}.csv', 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([employee_id, intimin])

            query = f"INSERT INTO monthlyreports VALUES('{month_name}', '{year}', {employee_name}, '{employee_id}', {intimin})"
            print(month_name, year, employee_name, employee_id, intimin)
            cur.execute(query)
            con.commit()
