
import pymysql
import csv
from datetime import date

from datetime import datetime
import datetime
months_list = [
    "January", 
    "February", 
    "March", 
    "April", 
    "May", 
    "June", 
    "July", 
    "August", 
    "September", 
    "October", 
    "November", 
    "December"
]

import os
  
# first check whether file exists or not
# calling remove method to delete the csv file
# in remove method you need to pass file name and type
 
con=pymysql.connect(host="localhost",user="root",password="",database="project")
cur=con.cursor()
cur.execute("SELECT EMPLOYEE_ID FROM EMPLOYEE")
cur.execute("DROP TABLE MONTHLYREPORTS"); 
monthlyreportstable = """CREATE TABLE IF NOT EXISTS MONTHLYREPORTS(
    MONTH_NAME VARCHAR(255),
    YEAR VARCHAR(255), 
    EMPLOYEE_ID INT, 
    EMPLOYEE_NAME VARCHAR(255), 
    DAYS INT 
)   """
cur.execute(monthlyreportstable)
today = date.today()

query = "SELECT * FROM EMPLOYEE"

cur.execute(query)

EMPLOYEE_RECORDS = cur.fetchall()
print(EMPLOYEE_RECORDS)
#os.chdir('G:\Final Project\MonthlyAttendanceReports')
#os.mkdir(year)
for month_name in months_list:
    import os

    year = today.strftime("%Y")
    file = f"MonthlyAttendanceReports/{month_name} - {year}.csv"

    if(os.path.exists(file) and os.path.isfile(file)):
        os.remove(file)

    month_first_date = f"{year}-{str(months_list.index(month_name) + 1)}-01 00:00:00"
    month_last_date = f"{year}-{str(months_list.index(month_name) + 1)}-31 23:59:59"
    for e in EMPLOYEE_RECORDS:
        employee_id = e[0]
        employee_name = e[2]
        print(employee_id)
        query = f"""
        SELECT COUNT(PUNCH) FROM ATTENDANCE WHERE EMPLOYEE_ID = "{employee_name}" 
        AND INOROUT = 'IN TIMING' AND PUNCH >= '{month_first_date}' AND PUNCH <= '{month_last_date}'
        """

        cur.execute(query)

        # exit()
        # for r in records:
        #     intiming = r
        intiming = cur.fetchone()

        intimin = intiming[0]


        with open(f'MonthlyAttendanceReports/ {month_name} - {year}.csv', 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([employee_id, intimin])

            query = f"INSERT INTO monthlyreports VALUES('{month_name}', '{year}', {employee_name}, '{employee_id}', {intimin})"
           # print(month_name, year, employee_name, employee_id, intimin)
            cur.execute(query)
            con.commit()
