from tkinter import *
import PIL
from PIL import ImageTk, Image
import csv
from tkinter import messagebox, ttk,filedialog
from tkinter.ttk import Combobox, Treeview
from tkcalendar import *
import cv2
import pymysql
import os
import PIL
from PIL import ImageTk, Image
from os import path

mydata=[]

root = Tk()
root.title("Attendance Using Face Recognition")
root.config(bg="white")
root.state("zoomed")
root.resizable(True, True)
#####################################################################
def showcmd():
    con = pymysql.connect(host="localhost", user="root", password="", database="project")
    cur = con.cursor()
    cur.execute("SELECT * FROM monthlyreports WHERE month_name = %s and year=%s", (monthcombo.get(),yearcombo.get()))
    '''
    if combo_search.get() == "" or searchentry == "":
        messagebox.showerror(message="Select all fields")
    if combo_search.get() == "Name":
        cur.execute("SELECT * FROM EMPLOYEE WHERE EMPLOYEE_NAME = %s", (searchentry.get()))
    if combo_search.get() == "Empid":
        cur.execute("SELECT * FROM EMPLOYEE WHERE EMPLOYEE_ID = %s", (searchentry.get()))
    if combo_search.get() == "Department":
        cur.execute("SELECT * FROM EMPLOYEE WHERE DEPARTMENT_NAME = %s", (searchentry.get()))
        '''
    rows = cur.fetchall()
    global mydata
    mydata=rows

    #   fetch_data()
    if len(rows) != 0:
        table.delete(*table.get_children())
        for row in rows:
            table.insert('', END, values=row)
        con.commit()
    else:
        messagebox.showerror(message="No records found")
    con.close()
def downloadbtn():
    if len(mydata)<1:
        messagebox.showerror("No data")
        return False


    fln = filedialog.asksaveasfilename(initialdir='Monthly Report/',title="Save CSV",defaultextension=".csv",filetypes=(("CSV File","*.csv"),("All files","*.*")))

    with open(fln,mode='w') as myfile:

        myfile.write('Month,Year,ID,Name,Count\n')
        exp_writer=csv.writer(myfile,delimiter=',')
        for i in mydata:
            exp_writer.writerow(i)
        messagebox.showinfo("Data Downloaded","Download successfull to"+os.path.basename(fln)+"successfully")


def bckbtn():
    root.withdraw()
    os.system("python dshboard.py")

def dailyatten():
    root.withdraw()
    os.system("python Dailyattendance.py")


#########################################################################Image

reportbg = PIL.Image.open("images/Attendance Report\Report.png")
reportbg = reportbg.resize((1528, 796))
reportbg = ImageTk.PhotoImage(reportbg)
reportbg_label = Label(image=reportbg)
reportbg_label.place(x=0, y=0)
##########################################################################
monthcombo= StringVar()
combo = ttk.Combobox(root, font=("yu gothic ui semibold", 12), state='readonly', width=15,
                     textvariable=monthcombo)
combo.set("Select Month")
combo['values'] = ['January','Febuary','March','April','May','June','July','August','September','October','November','December']
combo.place(x=350, y=330)

values=[]
for value in range(1999,2050):
    values.append(value)
yearcombo= StringVar()
comboyear = ttk.Combobox(root, font=("yu gothic ui semibold", 12), state='readonly', width=15,
                     textvariable=yearcombo)
comboyear.set("Select Year")
comboyear['values'] = values
comboyear.place(x=350, y=387)



#########################################################################
btnshow = ImageTk.PhotoImage \
    (file='images/Attendance Report/Show.png')
show_button = Button(root, image=btnshow, relief=FLAT, borderwidth=0, background="white",
                      activebackground="white", cursor="hand2")
show_button.place(x=230, y=470)
show_button.config(command=showcmd)


back = ImageTk.PhotoImage \
    (file='images/Attendance Report/previus.png')
back_button = Button(root, image=back, relief=FLAT, borderwidth=0, background="white",
                     activebackground="white", cursor="hand2")
back_button.place(x=20, y=15)
back_button.config(command=bckbtn)



download = ImageTk.PhotoImage \
    (file='images/Attendance Report/downloadbtn.png')
download_button = Button(root, image=download, relief=FLAT, borderwidth=0, background="white",
                     activebackground="white", cursor="hand2")
download_button.place(x=350, y=470)
download_button.config(command=downloadbtn)


dailyattendance = ImageTk.PhotoImage \
    (file='images/Daily Attendance/Daily att.png')
dailyattendancebtn = Button(root, image=dailyattendance, relief=FLAT, borderwidth=0, background="white",
                      activebackground="white", cursor="hand2")
dailyattendancebtn.place(x=150, y=12)
dailyattendancebtn.config(command=dailyatten)
##############################################################################Frameee
tableFrame = Frame(root, bg='white', relief=GROOVE, borderwidth=1)
tableFrame.place(x=730, y=200, width=700, height=500)

style = ttk.Style()
style.configure('Treeview.Heading', font=('arial', 10))
scroll_x = Scrollbar(tableFrame, orient=HORIZONTAL)
scroll_y = Scrollbar(tableFrame, orient=VERTICAL)
table = ttk.Treeview(tableFrame,
                     columns=('Month','Year', 'ID', 'Name', 'Total_att')
                     , yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
scroll_x.pack(side=BOTTOM, fill=X)
scroll_y.pack(side=RIGHT, fill=Y)
scroll_x.config(command=table.xview)
scroll_y.config(command=table.yview)
table.heading('Month', text='Month')
table.column('Month', width=80)
table.heading('Year', text='Year')
table.column('Year', width=80)
table.heading('ID', text='Employee Id')
table.column('ID', width=80)
table.heading('Name', text='Employee Name')
#table.column('Employee Id', width=100)
table.heading('Total_att', text='Total Attendance')
table.column('Total_att', width=50)

table['show'] = 'headings'
table.pack(fill=BOTH, expand=1)

table.bind("<ButtonRelease-1>")








root.mainloop()