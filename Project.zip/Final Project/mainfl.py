from tkinter import *
import PIL
from PIL import ImageTk, Image
import csv
from tkinter import messagebox, ttk
from tkinter.ttk import Combobox, Treeview
from tkcalendar import *
import cv2
import pymysql
import os
root = Tk()
root.title("Attendance Using Face Recognition")
root.config(bg="white")
# root.geometry("550x340+480+230")
root.state("zoomed")
root.resizable(True, True)


def addemployee():
    con = pymysql.connect(host="localhost", user="root", password="", database="project")
    cur = con.cursor()
    CREATEEMPLOYEETABLE = """CREATE TABLE IF NOT EXISTS EMPLOYEE
                            (EMPLOYEE_NAME VARCHAR(255), 
                            EMPLOYEE_GENDER VARCHAR(255), 
                            EMPLOYEE_ID INT, 
                             DEPARTMENT_NAME VARCHAR(255), 
                            CONTACTVAL VARCHAR(255), 
                            DATE_OF_BIRTH DATE, 
                            DATE_OF_JOINING DATE)"""
    cur.execute(CREATEEMPLOYEETABLE)
    try:
        notok = 0
        if nameval.get() == "":
            messagebox.showerror("Error", "Enter Name of employee")
            notok = 1

        if genderval.get() == "":
            messagebox.showerror("Error", "Choose gender of the employee")
            notok = 1
        if idval.get() == "":
            messagebox.showerror("Error", "Enter employee ID")
            notok = 1
        print("SELECT EMPLOYEE_NAME FROM EMPLOYEE WHERE EMPLOYEE_ID = %s", (idval.get()))
        print("SELECT EMPLOYEE_NAME FROM EMPLOYEE WHERE EMPLOYEE_ID = %s", (idval.get()))
        cur.execute("SELECT EMPLOYEE_NAME FROM EMPLOYEE WHERE EMPLOYEE_ID = %s", (idval.get()))
        results = cur.fetchall()
        yes = False
        for r in results:
            print(r)
            yes = True
            print("---------------")

        print(results)
        if yes:
            messagebox.showerror("Error", "This employee ID is already taken, try another one")
            root.withdraw()
            os.system("python mainfl.py")

        if comboval.get() == "":
            messagebox.showerror("Error", "Select Department of the Employee")
            notok = 1
        if dobval.get() == "":
            messagebox.showerror("Error", "Add date of birth in YYYY-MM-DD format")
            notok = 1
        if dojval.get() == "":
            messagebox.showerror("Error", "Type Date of Joining in YYYY-MM-DD format")
            notok = 1

    except:
        print("Every value is validated and is correct")
    finally:
        print("Adding values to database")
        if notok == 0:
            cur.execute('insert into employee values(%s,%s,%s,%s,%s,%s,%s)', (
                nameval.get(), genderval.get(), idval.get(), comboval.get(), contactval.get(), dobval.get(),
                dojval.get()))
            print(f"""
            Name: {nameval.get()}, 
            {genderval.get()},
            {idval.get()},
            {comboval.get()},
            {contactval.get()},
            {dobval.get()},
            {dojval.get()}
            """)
            con.commit()
            messagebox.showinfo("success", 'Click on upload photos to enable attendance management for the employee')
            fetch_data()
            # clear()
            con.close()


def updateemp():
    con = pymysql.connect(host="localhost", user="root", password="", database="project")
    cur = con.cursor()
    UPDATE_EMPLOYEE_RECORDS = """UPDATE EMPLOYEE SET EMPLOYEE_NAME=%s, EMPLOYEE_GENDER=%s, DEPARTMENT_NAME=%s, CONTACTVAL=%s, DATE_OF_BIRTH=%s, DATE_OF_JOINING=%s where EMPLOYEE_ID=%s,""", (
        nameval.get(), genderval.get(), comboval.get(), contactval.get(), dobval.get(), dojval.get(), idval.get())
    print(
        """UPDATE EMPLOYEE SET EMPLOYEE_NAME=%s, EMPLOYEE_GENDER=%s, DEPARTMENT_NAME=%s, CONTACTVAL=%s, DATE_OF_BIRTH=%s, DATE_OF_JOINING=%s where EMPLOYEE_ID=%s,""",
        (nameval.get(), genderval.get(), comboval.get(), contactval.get(), dobval.get(), dojval.get(), idval.get()))
    cur.execute(
        """UPDATE EMPLOYEE SET EMPLOYEE_NAME=%s, EMPLOYEE_GENDER=%s, DEPARTMENT_NAME=%s, CONTACTVAL=%s, DATE_OF_BIRTH=%s, DATE_OF_JOINING=%s where EMPLOYEE_ID=%s""",
        (nameval.get(), genderval.get(), comboval.get(), contactval.get(), dobval.get(), dojval.get(), idval.get()))
    con.commit()

    messagebox.showinfo("success", 'Employee details have been Updated Successfully')
    fetch_data()
    clear()
    con.close()


def deleteemp():
    con = pymysql.connect(host="localhost", user="root", password="", database="project")
    cur = con.cursor()
    if idval.get() == "":
        messagebox.showerror(message="This employee ID is not valid")
        exit()
    # try:
    cur.execute('delete from employee where EMPLOYEE_ID=%s', idval.get())
    con.commit()


    messagebox.showinfo(message="Deleted record of employee")
    id = idval.get()
    name = nameval.get()
    try:
        for i in range(1, 62):
            print(name, id, i)
            file_name = "TrainingImage\ " + name + "-" + id + '-' + str(i) + ".jpg"
            print(file_name)
            os.remove(file_name)
            print("removed files")
    finally:
        messagebox.showinfo(message="Deleted all photos")

    clear()
    root.withdraw()
    os.system("python mainfl.py")
    con.close()
    # fetch_data()
    # root.destroy()
    # import main


def cleardata():
    clear()


def fetch_data():
    con = pymysql.connect(host="localhost", user="root", password="", database="project")
    cur = con.cursor()
    cur.execute('select * from employee')
    rows = cur.fetchall()
    if len(rows) != 0:
        table.delete(*table.get_children())
        for row in rows:
            table.insert('', END, values=row)
        con.commit()
    con.close()


def clear():
    nameval.set("")
    genderval.set("")
    idval.set("")
    comboval.set("")
    contactval.set("")
    dobval.set("")
    dojval.set("")


def get_cursor(ev):
    cursor_row = table.focus()
    contents = table.item(cursor_row)
    row = contents['values']
    nameval.set(row[0])
    genderval.set(row[1])
    idval.set(row[2])
    comboval.set(row[3])
    contactval.set(row[4])
    dobval.set(row[5])
    dojval.set(row[6])


def addphoto():
    print("HI from addphoto")
    Id = (identry.get())
    name = (nameentry.get())
    print(Id, name)
    if Id == "" or name == "":
        messagebox.showerror(message="Enter ID and name to upload employee photos")
    if is_number(Id) and name.isalpha():
        print("Every value is correct")
        cam = cv2.VideoCapture(0)
      #  address="http://192.168.43.1:8080/video"
     #   cam.open(address)
        harcascadePath = "haarcascade_frontalface_default.xml"
        print("Get the harcascade path")
        detector = cv2.CascadeClassifier(harcascadePath)
        print("detected classifier")
        print("processing")
        sampleNum = 0
        print("Number of pictures clicked", sampleNum)
        while True:
            ret, img = cam.read()
            print("processing")
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = detector.detectMultiScale(gray, 1.3, 5)
            for (x, y, w, h) in faces:
                cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
                # incrementing sample number
                sampleNum = sampleNum + 1
                print("Number of pictures clicked: ", sampleNum)
                # saving the captured face in the dataset folder TrainingImage
                cv2.imwrite("TrainingImage\ " + name + "-" + Id + '-' + str(sampleNum) + ".jpg", gray[y:y + h, x:x + w])
                # display the frame
                cv2.imshow('frame', img)
                print("Images taken through camera")
            # wait for 100 miliseconds
            if cv2.waitKey(100) & 0xFF == ord('q'):
                break
            # break if the sample number is morethan 100
            elif sampleNum > 60:
                break
        cam.release()
        cv2.destroyAllWindows()
        messagebox.showinfo("Done", "Images Saved for ID : " + Id + "  and Name : " + name)
        row = [Id, name]
        with open('Employee\Details.csv', 'a+') as csvFile:
            writer = csv.writer(csvFile)
            writer.writerow(row)
        csvFile.close()
    # message.configure(text=res)
    else:
        if is_number(Id):
            res = "Enter Alphabetical Name"
            messagebox.showerror(message=res)
        # message.configure(text=res)
        if name.isalpha():
            res = "Enter Numeric Id"
            messagebox.showerror(message=res)
            # message.configure(text=res)


def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        pass

    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except (TypeError, ValueError):
        pass

    return False


def searchbtn():
    con = pymysql.connect(host="localhost", user="root", password="", database="project")
    cur = con.cursor()
    if combo_search.get() == "" or searchentry == "":
        messagebox.showerror(message="Select all fields")
    if combo_search.get() == "Name":
        cur.execute("SELECT * FROM EMPLOYEE WHERE EMPLOYEE_NAME = %s", (searchentry.get()))
    if combo_search.get() == "Empid":
        cur.execute("SELECT * FROM EMPLOYEE WHERE EMPLOYEE_ID = %s", (searchentry.get()))
    if combo_search.get() == "Department":
        cur.execute("SELECT * FROM EMPLOYEE WHERE DEPARTMENT_NAME = %s", (searchentry.get()))
    rows = cur.fetchall()
    #   fetch_data()
    if len(rows) != 0:
        table.delete(*table.get_children())
        for row in rows:
            table.insert('', END, values=row)
        con.commit()
    else:
        messagebox.showerror(message="No records found")
    con.close()


def showallbtn():
    fetch_data()


def previusbtn():

    root.withdraw()
    os.system("python dshboard.py")


mainbg = PIL.Image.open("images/Management Emp/bgmain.png")
mainbg = mainbg.resize((1528, 796))
mainbg = ImageTk.PhotoImage(mainbg)
mainbg_label = Label(image=mainbg)
mainbg_label.place(x=0, y=0)
###################################################################################### Table Frame
tableFrame = Frame(root, bg='white', relief=GROOVE, borderwidth=1)
tableFrame.place(x=800, y=220, width=700, height=500)

style = ttk.Style()
style.configure('Treeview.Heading', font=('arial', 10))
scroll_x = Scrollbar(tableFrame, orient=HORIZONTAL)
scroll_y = Scrollbar(tableFrame, orient=VERTICAL)
table = ttk.Treeview(tableFrame,
                     columns=('Name', 'Gender', 'Employee Id', 'Department', 'Contact No.', 'D.O.B', 'Date of Joining')
                     , yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
scroll_x.pack(side=BOTTOM, fill=X)
scroll_y.pack(side=RIGHT, fill=Y)
scroll_x.config(command=table.xview)
scroll_y.config(command=table.yview)
table.heading('Name', text='Name')
table.heading('Gender', text='Gender')
table.column('Gender', width=80)
table.heading('Employee Id', text='Employee Id')
table.column('Employee Id', width=100)
table.heading('Department', text='Department')
table.heading('Contact No.', text='Contact No.')
table.column('Contact No.', width=150)
table.heading('D.O.B', text='D.O.B')
table.column('D.O.B', width=150)
table.heading('Date of Joining', text='Date of Joining')
table.column('Date of Joining', width=150)
table['show'] = 'headings'
table.pack(fill=BOTH, expand=1)

table.bind("<ButtonRelease-1>", get_cursor)


#####################################################################################Click
def clickname(*args):
    nameentry.delete(0, 'end')


def clickid(*args):
    identry.delete(0, "end")


def clickcontact(*args):
    contactentry.delete(0, "end")


# call function when we leave entry box
def leave(*args):
    nameentry.delete(0, 'end')
    nameentry.insert(0, 'Enter Text:- ')
    root.focus()


##########################################################################################################Entry
nameval = StringVar()
genderval = StringVar()
idval = StringVar()
contactval = StringVar()
comboval = StringVar()
dobval = StringVar()
dojval = StringVar()

nameentry = Entry(root, relief=FLAT, bg="white", fg="Black", font=("yu gothic ui semibold", 12, 'bold'),
                  textvariable=nameval)
nameentry.place(x=365, y=175, width=244)
nameentry.insert(0, 'Enter Full Name')
nameentry.bind("<Button-1>", clickname)

identry = Entry(root, relief=FLAT, bg="white", fg="Black", font=("yu gothic ui semibold", 12, 'bold'),
                textvariable=idval)
identry.place(x=365, y=235, width=244)
identry.insert(0, 'Enter Id')
identry.bind("<Button-1>", clickid)

r1 = Radiobutton(root, text="Male", padx=20, font=('yu gothic ui semibold', 13, 'bold'), bg='white', fg="Black",
                 value="Male", variable=genderval)
r1.place(x=350, y=295)
r2 = Radiobutton(root, text="Female", padx=20, font=('yu gothic ui semibold', 13, 'bold'), bg='white', fg="Black",
                 value="Female", variable=genderval)
r2.select()
r1.select()
r2.place(x=470, y=295)

dobentry = DateEntry(root, font=('yu gothic ui semibold', 12), relief=FLAT, textvariable=dobval, foreground="Black",
                     width=25, date_pattern='dd/mm/yyy', borderwidth=0)
dobentry._set_text("DD/MM/YYYY")
dobentry.place(x=355, y=360)

contactentry = Entry(root, relief=FLAT, bg="white", fg="Black", font=("yu gothic ui semibold", 12, 'bold'),
                     textvariable=contactval)
contactentry.place(x=365, y=425, width=245)
contactentry.insert(0, 'Enter Contact No.')
contactentry.bind("<Button-1>", clickcontact)

con = pymysql.connect(host="localhost", user="root", password="", database="project")
cur = con.cursor()

sql = ('CREATE TABLE IF NOT EXISTS DEPARTMENT (DEPARTMENT_NAME VARCHAR(255))')
cur.execute(sql)

sql = ('select DEPARTMENT_NAME from department')
cur.execute(sql)
rows = cur.fetchall()
combo = ttk.Combobox(root, font=("yu gothic ui semibold", 12), state='readonly', width=25,
                     textvariable=comboval)
combo.set("Select Department")
combo['values'] = rows
combo.place(x=355, y=485)
con.close()

dojentry = DateEntry(root, font=("yu gothic ui semibold", 12), textvariable=dojval, width=25, date_pattern='dd/mm/yyy')
dojentry._set_text("DD/MM/YYYY")
dojentry.place(x=355, y=545)

########################################################################################################################## Add employee Buttons
btnadd = ImageTk.PhotoImage \
    (file='images/Management Emp/detailadd.png')
add_button = Button(root, image=btnadd, relief=FLAT, borderwidth=0, background="white",
                    activebackground="white", cursor="hand2")
add_button.place(x=90, y=620)
add_button.config(command=addemployee)


btnupdate = ImageTk.PhotoImage \
    (file='images/Management Emp/detailupdate.png')
update_button = Button(root, image=btnupdate, relief=FLAT, borderwidth=0, background="white",
                       activebackground="white", cursor="hand2")
update_button.place(x=225, y=620)
update_button.config(command=updateemp)


btndelete = ImageTk.PhotoImage \
    (file='images/Management Emp/detaildelete.png')
delete_button = Button(root, image=btndelete, relief=FLAT, borderwidth=0, background="white",
                       activebackground="white", cursor="hand2")
delete_button.place(x=360, y=620)
delete_button.config(command=deleteemp)


btnclear = ImageTk.PhotoImage \
    (file='images/Management Emp/detailclear.png')
clear_button = Button(root, image=btnclear, relief=FLAT, borderwidth=0, background="white",
                      activebackground="white", cursor="hand2")
clear_button.place(x=485, y=620)
clear_button.config(command=cleardata)


btnaddphoto = ImageTk.PhotoImage \
    (file='images/Management Emp/photoaddbtn.png')
addphoto_button = Button(root, image=btnaddphoto, relief=FLAT, borderwidth=0, background="white",
                         activebackground="white", cursor="hand2")
addphoto_button.place(x=160, y=690)
addphoto_button.config(command=addphoto)

#################################################################################################### Emp record
search_by = StringVar()
search_txt = StringVar()

combo_search = ttk.Combobox(root, width=15, font=("times new roman", 14), state='readonly', textvariable=search_by)
combo_search.set("Search By:")
combo_search['values'] = ["Empid", "Name", "Department"]
combo_search.place(x=835, y=170)

searchentry = Entry(root, relief=FLAT, bg="white", fg="Black", font=("yu gothic ui semibold", 12, 'bold'),
                    textvariable=search_txt)
searchentry.place(x=1035, y=170, width=125)


search = ImageTk.PhotoImage \
    (file='images/Management Emp/searchbtn.png')
search_button = Button(root, image=search, relief=FLAT, borderwidth=0, background="white",
                       activebackground="white", cursor="hand2")
search_button.place(x=1200, y=163)
search_button.config(command=searchbtn)


btnshowall = ImageTk.PhotoImage \
    (file='images/Management Emp/showallbtn.png')
showall_button = Button(root, image=btnshowall, relief=FLAT, borderwidth=0, background="white",
                        activebackground="white", cursor="hand2")
showall_button.place(x=1330, y=163)
showall_button.config(command=showallbtn)


back = ImageTk.PhotoImage \
    (file='images/Management Emp/previus.png')
back_button = Button(root, image=back, relief=FLAT, borderwidth=0, background="white",
                     activebackground="white", cursor="hand2")
back_button.place(x=20, y=15)
back_button.config(command=previusbtn)




root.mainloop()
