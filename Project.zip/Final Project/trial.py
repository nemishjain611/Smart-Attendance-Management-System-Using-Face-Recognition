
from tkinter import *
from tkinter import messagebox, ttk
from tkinter.ttk import Treeview
root = Tk()
root.title("Attendance Using Face Recognition")
root.config(bg="white")
# root.geometry("550x340+480+230")
root.state("zoomed")
root.resizable(True, True)
tableFrame = Frame(root, bg='white', relief=GROOVE, borderwidth=1)
tableFrame.place(x=800, y=220, width=700, height=500)

style = ttk.Style()
style.configure('Treeview.Heading', font=('arial', 10))
scroll_x = Scrollbar(tableFrame, orient=HORIZONTAL)
scroll_y = Scrollbar(tableFrame, orient=VERTICAL)
table = ttk.Treeview(tableFrame,columns=('DepartmentName'),
                      yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
scroll_x.pack(side=BOTTOM, fill=X)
scroll_y.pack(side=RIGHT, fill=Y)
scroll_x.config(command=table.xview)
scroll_y.config(command=table.yview)
table.heading('DepartmentName', text='Department Name')

table['show'] = 'headings'
table.pack(fill=BOTH, expand=1)

#table.bind("<ButtonRelease-1>", get_cursor)

root.mainloop()