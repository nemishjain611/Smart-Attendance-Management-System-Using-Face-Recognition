from tkinter import *
import PIL
from PIL import ImageTk, Image
from tkinter import messagebox
import os

root = Tk()
root.title("Attendance Using Face Recognition")
root.config(bg="white")
root.state("zoomed")
root.resizable(True, True)




def addempcmd():
    root.withdraw()
    os.system("python mainfl.py")

def adddeptcmd():
    root.withdraw()
    os.system("python managedept.py")

def traincmd():
    os.system("python trainhar.py")
    messagebox.showinfo(title="Trained", message="Your models has been trained Successfully.")
def reportcmd():
    os.system("python generatereports.py")
    root.withdraw()
    os.system("python Report.py")
def signoutcmd():
    root.withdraw()
    os.system("python firstfront.py")


dshboardimg = PIL.Image.open("images/Dashboard/dshboard.png")
dshboardimg = dshboardimg.resize((1525, 799))
dshboardimg = ImageTk.PhotoImage(dshboardimg)
dshboard_label = Label(image=dshboardimg)
dshboard_label.place(x=0, y=0)

addempbtn = ImageTk.PhotoImage \
    (file='images\Dashboard\empaddbtn.png')
addemp_button = Button(root, image=addempbtn, relief=FLAT, borderwidth=0, background="white",
                       activebackground="white", cursor="hand2")
addemp_button.place(x=100, y=120)
addemp_button.config(command=addempcmd)



deptadd = ImageTk.PhotoImage \
    (file='images\Dashboard\deptadd.png')
deptadd_button = Button(root, image=deptadd, relief=FLAT, borderwidth=0, background="white",
                       activebackground="white", cursor="hand2")
deptadd_button.place(x=100, y=240)
deptadd_button.config(command=adddeptcmd)



reportbtn = ImageTk.PhotoImage \
    (file='images\Dashboard\empreportbtn.png')
report_button = Button(root, image=reportbtn, relief=FLAT, borderwidth=0, background="white",
                       activebackground="white", cursor="hand2")
report_button.place(x=100, y=360)
report_button.config(command=reportcmd)



trainbtn = ImageTk.PhotoImage \
    (file='images\Dashboard\imgtrainbtn.png')
train_button = Button(root, image=trainbtn, relief=FLAT, borderwidth=0, background="white",
                      activebackground="white", cursor="hand2")
train_button.place(x=100, y=480)
train_button.config(command=traincmd)



signoutbtn = ImageTk.PhotoImage \
    (file='images\Dashboard\signoutbtn.png')
signout_button = Button(root, image=signoutbtn, relief=FLAT, borderwidth=0, background="white",
                        activebackground="white", cursor="hand2", command=signoutcmd)
signout_button.place(x=200, y=600)
signout_button.config(command=signoutcmd)

root.mainloop()
