-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2021 at 09:40 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `EMPLOYEE_ID` int(11) DEFAULT NULL,
  `EMPLOYEE_NAME` varchar(255) DEFAULT NULL,
  `PUNCH` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `INOROUT` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`EMPLOYEE_ID`, `EMPLOYEE_NAME`, `PUNCH`, `INOROUT`) VALUES
(1, 'Nemish', '2021-05-29 03:14:04', 'IN TIMING'),
(1, 'Nemish', '2021-05-29 03:39:09', 'OUT TIMING'),
(2, 'Seema', '2021-05-29 03:48:11', 'IN TIMING'),
(4, 'Sunny', '2021-05-29 03:49:58', 'IN TIMING'),
(4, 'Sunny', '2021-05-29 04:08:24', 'OUT TIMING'),
(2, 'Seema', '2021-05-29 04:10:05', 'OUT TIMING'),
(5, 'Vidit', '2021-05-29 04:16:15', 'IN TIMING'),
(5, 'Vidit', '2021-05-29 04:16:58', 'OUT TIMING'),
(6, 'Sakib', '2021-05-29 06:13:47', 'IN TIMING'),
(6, 'Sakib', '2021-05-29 06:15:44', 'OUT TIMING'),
(7, 'Israr', '2021-05-29 06:34:13', 'IN TIMING'),
(7, 'Israr', '2021-05-29 06:35:18', 'OUT TIMING'),
(8, 'Ikhlas', '2021-05-29 07:30:20', 'IN TIMING'),
(8, 'Ikhlas', '2021-05-29 07:31:40', 'OUT TIMING'),
(9, 'Iliyas', '2021-05-29 07:38:56', 'IN TIMING'),
(9, 'Iliyas', '2021-05-29 07:39:36', 'OUT TIMING');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `DEPARTMENT_NAME` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`DEPARTMENT_NAME`) VALUES
('HR'),
('IT'),
('Marketing');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `EMPLOYEE_NAME` varchar(255) NOT NULL,
  `EMPLOYEE_GENDER` varchar(255) DEFAULT NULL,
  `EMPLOYEE_ID` varchar(11) NOT NULL,
  `DEPARTMENT_NAME` varchar(255) DEFAULT NULL,
  `CONTACTVAL` varchar(255) DEFAULT NULL,
  `DATE_OF_BIRTH` varchar(20) NOT NULL,
  `DATE_OF_JOINING` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`EMPLOYEE_NAME`, `EMPLOYEE_GENDER`, `EMPLOYEE_ID`, `DEPARTMENT_NAME`, `CONTACTVAL`, `DATE_OF_BIRTH`, `DATE_OF_JOINING`) VALUES
('Nemish', 'Male', '1', 'IT', '7615059693', '06/03/1999', '17/06/2021'),
('Seema', 'Female', '2', 'HR', '9460115762', '12/09/1975', '03/06/2021'),
('Manoj', 'Male', '3', 'HR', '9460093001', '12/10/1971', '03/06/2021'),
('Sunny', 'Male', '4', 'Marketing', '9660419270', '06/04/1997', '03/06/2021'),
('Vidit', 'Male', '5', 'IT', '9314141459', '20/05/2004', '17/05/2021'),
('Sakib', 'Male', '6', 'IT', '8983566323', '28/08/1998', '29/05/2021'),
('Israr', 'Male', '7', 'HR', '8087775049', '16/10/1999', '01/04/2021'),
('Ikhlas', 'Male', '8', 'IT', '8446148267', '16/08/1998', '01/05/2021'),
('Iliyas', 'Male', '9', 'Marketing', '8626005321', '05/12/2002', '05/05/2021');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `USERNAME` varchar(255) NOT NULL,
  `PASSWORD` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`USERNAME`, `PASSWORD`) VALUES
('taralacpaint', 'taralac@123'),
('taralacpaint', 'taralac@123');

-- --------------------------------------------------------

--
-- Table structure for table `monthlyreports`
--

CREATE TABLE `monthlyreports` (
  `MONTH_NAME` varchar(10) DEFAULT NULL,
  `YEAR` varchar(4) DEFAULT NULL,
  `EMPLOYEE_ID` int(11) DEFAULT NULL,
  `EMPLOYEE_NAME` varchar(255) DEFAULT NULL,
  `DAYS` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `monthlyreports`
--

INSERT INTO `monthlyreports` (`MONTH_NAME`, `YEAR`, `EMPLOYEE_ID`, `EMPLOYEE_NAME`, `DAYS`) VALUES
('January', '2021', 1, 'Nemish', 0),
('January', '2021', 2, 'Seema', 0),
('January', '2021', 3, 'Manoj', 0),
('January', '2021', 4, 'Sunny', 0),
('January', '2021', 5, 'Vidit', 0),
('January', '2021', 6, 'Sakib', 0),
('January', '2021', 7, 'Israr', 0),
('January', '2021', 8, 'Ikhlas', 0),
('February', '2021', 1, 'Nemish', 0),
('February', '2021', 2, 'Seema', 0),
('February', '2021', 3, 'Manoj', 0),
('February', '2021', 4, 'Sunny', 0),
('February', '2021', 5, 'Vidit', 0),
('February', '2021', 6, 'Sakib', 0),
('February', '2021', 7, 'Israr', 0),
('February', '2021', 8, 'Ikhlas', 0),
('March', '2021', 1, 'Nemish', 0),
('March', '2021', 2, 'Seema', 0),
('March', '2021', 3, 'Manoj', 0),
('March', '2021', 4, 'Sunny', 0),
('March', '2021', 5, 'Vidit', 0),
('March', '2021', 6, 'Sakib', 0),
('March', '2021', 7, 'Israr', 0),
('March', '2021', 8, 'Ikhlas', 0),
('April', '2021', 1, 'Nemish', 0),
('April', '2021', 2, 'Seema', 0),
('April', '2021', 3, 'Manoj', 0),
('April', '2021', 4, 'Sunny', 0),
('April', '2021', 5, 'Vidit', 0),
('April', '2021', 6, 'Sakib', 0),
('April', '2021', 7, 'Israr', 0),
('April', '2021', 8, 'Ikhlas', 0),
('May', '2021', 1, 'Nemish', 1),
('May', '2021', 2, 'Seema', 1),
('May', '2021', 3, 'Manoj', 0),
('May', '2021', 4, 'Sunny', 1),
('May', '2021', 5, 'Vidit', 1),
('May', '2021', 6, 'Sakib', 1),
('May', '2021', 7, 'Israr', 1),
('May', '2021', 8, 'Ikhlas', 1),
('June', '2021', 1, 'Nemish', 0),
('June', '2021', 2, 'Seema', 0),
('June', '2021', 3, 'Manoj', 0),
('June', '2021', 4, 'Sunny', 0),
('June', '2021', 5, 'Vidit', 0),
('June', '2021', 6, 'Sakib', 0),
('June', '2021', 7, 'Israr', 0),
('June', '2021', 8, 'Ikhlas', 0),
('July', '2021', 1, 'Nemish', 0),
('July', '2021', 2, 'Seema', 0),
('July', '2021', 3, 'Manoj', 0),
('July', '2021', 4, 'Sunny', 0),
('July', '2021', 5, 'Vidit', 0),
('July', '2021', 6, 'Sakib', 0),
('July', '2021', 7, 'Israr', 0),
('July', '2021', 8, 'Ikhlas', 0),
('August', '2021', 1, 'Nemish', 0),
('August', '2021', 2, 'Seema', 0),
('August', '2021', 3, 'Manoj', 0),
('August', '2021', 4, 'Sunny', 0),
('August', '2021', 5, 'Vidit', 0),
('August', '2021', 6, 'Sakib', 0),
('August', '2021', 7, 'Israr', 0),
('August', '2021', 8, 'Ikhlas', 0),
('September', '2021', 1, 'Nemish', 0),
('September', '2021', 2, 'Seema', 0),
('September', '2021', 3, 'Manoj', 0),
('September', '2021', 4, 'Sunny', 0),
('September', '2021', 5, 'Vidit', 0),
('September', '2021', 6, 'Sakib', 0),
('September', '2021', 7, 'Israr', 0),
('September', '2021', 8, 'Ikhlas', 0),
('October', '2021', 1, 'Nemish', 0),
('October', '2021', 2, 'Seema', 0),
('October', '2021', 3, 'Manoj', 0),
('October', '2021', 4, 'Sunny', 0),
('October', '2021', 5, 'Vidit', 0),
('October', '2021', 6, 'Sakib', 0),
('October', '2021', 7, 'Israr', 0),
('October', '2021', 8, 'Ikhlas', 0),
('November', '2021', 1, 'Nemish', 0),
('November', '2021', 2, 'Seema', 0),
('November', '2021', 3, 'Manoj', 0),
('November', '2021', 4, 'Sunny', 0),
('November', '2021', 5, 'Vidit', 0),
('November', '2021', 6, 'Sakib', 0),
('November', '2021', 7, 'Israr', 0),
('November', '2021', 8, 'Ikhlas', 0),
('December', '2021', 1, 'Nemish', 0),
('December', '2021', 2, 'Seema', 0),
('December', '2021', 3, 'Manoj', 0),
('December', '2021', 4, 'Sunny', 0),
('December', '2021', 5, 'Vidit', 0),
('December', '2021', 6, 'Sakib', 0),
('December', '2021', 7, 'Israr', 0),
('December', '2021', 8, 'Ikhlas', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`DEPARTMENT_NAME`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD UNIQUE KEY `EMPLOYEE_ID` (`EMPLOYEE_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
