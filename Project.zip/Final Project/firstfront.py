from tkinter import *
from tkinter import messagebox
import PIL
from PIL import ImageTk, Image
import pymysql
import os

root = Tk()
root.title("Attendance Using Face Recognition")
root.config(bg="white")
# root.geometry("550x340+480+230")
root.state("zoomed")
root.resizable(True, True)


def adminlogincmd():
    root.withdraw()
    os.system("python lgn.py")


def takeattendance():
    os.system("python markattendanceMain.py")
    #root.overrideredirect(1)
    #root.withdraw()
    #os.system("python firstfront.py")



bgfront = PIL.Image.open("images/front/Frontbg.png")
bgfront = bgfront.resize((1530, 805))
bgfront = ImageTk.PhotoImage(bgfront)
bgfront_label = Label(image=bgfront)
bgfront_label.place(x=0, y=0)


adminlogin = ImageTk.PhotoImage \
    (file='images/front/Admin Login.png')
adminlogin_button = Button(root, image=adminlogin, relief=FLAT, borderwidth=0, background="white",
                           activebackground="white", cursor="hand2")
adminlogin_button.place(x=100, y=450)
adminlogin_button.configure(command=adminlogincmd)

takeattend = ImageTk.PhotoImage \
    (file='images/front/Take Attendance.png')
takeattend_button = Button(root, image=takeattend, relief=FLAT, borderwidth=0, background="white",
                           activebackground="white", cursor="hand2")
takeattend_button.place(x=100, y=600)
takeattend_button.config(command=takeattendance)

root.mainloop()
